#include <iostream>
#include <string>
#include <vector>

#include "event.h"

using namespace std;
Event::Event() {}

//Event Implementation
